/*
 * NetWork.h
 *
 *  Created on: Oct 20, 2016
 *      Author: zhangyalei
 */

#ifndef NETWORK_H_
#define NETWORK_H_

#include "List.h"
#include "Thread.h"
#include "Epoll_Watcher.h"
#include "Svc.h"

class Endpoint;
class Network: public Thread, public Event_Handler {
	typedef Mutex_Lock Svc_Map_Lock;
	typedef std::unordered_map<int, Svc *> Svc_Map;
	typedef List<int, Mutex_Lock> Drop_List;
public:
	Network(void);
	virtual ~Network(void);

	int init(Endpoint *endpoint, int receive_timeout);
	int fini(void);

	virtual void run_handler(void);

	int push_drop(int cid);
	int process_drop(void);

	int register_svc(Svc *svc);
	int unregister_svc(Svc *svc);

	virtual int drop_handler(int cid);
	virtual Svc *find_svc(int cid);

	int register_timer(void);
	virtual int handle_timeout(const Time_Value &tv);

protected:
	Endpoint *endpoint_;

private:
	Epoll_Watcher *reactor_;
	Drop_List drop_list_;

	Svc_Map_Lock svc_map_lock_;
	Svc_Map svc_map_;

	bool register_timer_;
};

#endif /* NETWORK_H_ */
