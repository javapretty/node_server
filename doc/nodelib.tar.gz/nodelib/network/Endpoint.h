/*
 * Endpoint.h
 *
 *  Created on: Sep 22, 2016
 *      Author: zhangyalei
 */

#ifndef ENDPOINT_H_
#define ENDPOINT_H_

#include "Base_Define.h"
#include "Block_Pool_Group.h"
#include "Object_Pool.h"
#include "Accept.h"
#include "Connect.h"
#include "Network.h"
#include "Svc.h"
#include "Svc_Static_List.h"

class Endpoint_Accept: public Accept {
public:
	virtual int accept_svc(int connfd);
};

class Endpoint_Connect: public Connect {
public:
	virtual int connect_svc(int connfd);
};

class Endpoint_Network: public Network {
public:
	virtual int drop_handler(int cid);
	virtual Svc *find_svc(int cid);
};

class Endpoint_Svc: public Svc {
public:
	virtual Block_Buffer *pop_block(int cid);
	virtual int push_block(int cid, Block_Buffer *buffer);
	virtual int post_block(Block_Buffer* buffer);

	virtual int register_network_handler(void);
	virtual int unregister_network_handler(void);

	virtual int close_handler(int cid);
};

class Endpoint {
public:
	typedef Object_Pool<Endpoint_Svc, Spin_Lock> Svc_Pool;
	typedef Svc_Static_List<Endpoint_Svc *, Spin_Lock> Svc_List;
	typedef Block_List<Thread_Mutex> Data_List;
	typedef List<int, Thread_Mutex> Int_List;

	Endpoint(void);
	virtual ~Endpoint(void);

	virtual int init(Endpoint_Info &endpoint_info);
	virtual int start(void);

	inline Svc_List &svc_list(void) { return svc_static_list_; }
	inline Svc_Pool &svc_pool(void) { return svc_pool_; }
	inline Data_List &block_list(void) { return block_list_;}
	inline Int_List &drop_list(void) { return drop_list_; }

	inline Endpoint_Accept &accept(void) { return accept_; }
	inline Endpoint_Connect &connect(void) { return connect_; }
	inline Endpoint_Network &network(void) { return network_; }

	inline Endpoint_Info &endpoint_info(void) { return endpoint_info_; }
	inline int get_cid(void) { return cid_; }
	inline void set_cid(int cid) { cid_ = cid; }

	Block_Buffer *pop_block(int cid);
	int push_block(int cid, Block_Buffer *buffer);
	int send_block(int cid, Block_Buffer &buffer);

	Svc *find_svc(int cid);
	int recycle_svc(int cid);
	int get_svc_info(Endpoint_Svc_Info &svc_info);
	void free_pool(void);

private:
	Svc_List svc_static_list_;
	Svc_Pool svc_pool_;
	Block_Pool_Group block_pool_group_;
	Data_List block_list_;
	Int_List drop_list_;

	Endpoint_Accept accept_;
	Endpoint_Connect connect_;
	Endpoint_Network network_;

	Endpoint_Info endpoint_info_;
	int32_t cid_;
};

class Server: public Endpoint {
public:
	Server(void);
	virtual ~Server(void);

	virtual int init(Endpoint_Info &endpoint_info);
	virtual int start(void);
};

class Connector: public Endpoint {
public:
	Connector(void);
	virtual ~Connector(void);

	virtual int init(Endpoint_Info &endpoint_info);
	virtual int start(void);
	int connect_server(std::string ip = "", int port = 0);
};

#endif /* ENDPOINT_H_ */
