/*
 * Bit_Buffer.h
 *
 *  Created on: Oct 31,2016
 *      Author: zhangyalei
 */

#ifndef BIT_BUFFER_H_
#define BIT_BUFFER_H_

#include <stdlib.h>
#include <string.h>

class Bit_Buffer {
public:
	Bit_Buffer(char* ary = nullptr, int len = 0) :
		byte_ary(ary), byte_size(len), byte_ary_capacity(len),
		bit_pos(0), read_byte_pos(0), read_only(false) {
		if(ary) {
			read_only = true;
		}
	}

	~Bit_Buffer() {
		clear();
	}

	bool is_readonly() const { return read_only; }

	void set_ary(char* ary, int len) {
		if(byte_ary && !read_only) {
			free(byte_ary);
		}
		byte_ary = ary;
		byte_size = len;
		byte_ary_capacity = len;
		read_only = true;
		bit_pos = 0;
		read_byte_pos = 0;
	}

	unsigned int get_bit_position() { return bit_pos; }
	unsigned int set_bit_position(unsigned int pos) {
		if(pos > byte_size * 8) {
			bit_pos = byte_size * 8;
		}
		else {
			bit_pos = pos;
		}

		return bit_pos;
	}

	unsigned int get_byte_size() {
		if(bit_pos > 0) {
			return byte_size + 1;
		}
		else {
			return byte_size;
		}
	}

	unsigned int get_byte_capacity() { return byte_ary_capacity; }
	int set_capability(unsigned int cap) {
		char* old_data = byte_ary;
		byte_ary = (char*)malloc(cap);

		if(old_data) {
			int data_size = cap > byte_size+1 ? byte_size+1:cap;
			memcpy(byte_ary, old_data, data_size);

			if(!read_only) {
				free(old_data);
			}
		}
		read_only = false;

		byte_ary_capacity = cap;
		if(byte_size > cap) {
			byte_size = cap;
		}
		if(bit_pos > byte_size * 8) {
			bit_pos = byte_size * 8;
		}

		return byte_size;
	}

	void clear() {
		if(byte_ary && !read_only) {
			free(byte_ary);
			byte_ary = nullptr;
		}
	}

	void reset() {
		if(!read_only) {
			byte_size = 0;
		}
		bit_pos = 0;
		read_byte_pos = 0;
	}

	void enlarge(int add_size) {
		if((byte_size + add_size) >= byte_ary_capacity) {
			set_capability(((byte_size + add_size) / 128 + 1 )* 128);
		}
	}

	void write_bool(bool b) {
		enlarge(1);
		_write_flag(b);
	}

	void write_int(int i, unsigned int bits) {
		if(bits == 0) {
			return;
		}

		enlarge(4);
		if(i < 0) {
			//将负整数转为二进制，第一位为标志位1
			_write_flag(true);
			_write_u32((unsigned int)-i, bits-1);
		}
		else {
			_write_flag(false);
			_write_u32((unsigned int)i, bits-1);
		}
	}

	void write_uint(unsigned int i, unsigned int bits) {
		enlarge(4);
		_write_u32(i ,bits);
	}

	void write_decimal(float f, unsigned int bits) {
		write_uint((unsigned int)(((f + 1) * .5) * ((1 << bits) - 1)), bits);
	}

	void write_udecimal(float f, unsigned int bits) {
		write_uint((unsigned int)(f * ((1 << bits) - 1)), bits);
	}

	//TODO:encode str with huffman tree
	void write_str(const char* str) {
		//参数为空时候，写入空字符串结尾符
		if (str == NULL) {
			str = "";	 // write /0
		}

		int len = strlen(str) + 1;
		if(len <= 0) {
			str = "";
			len = 1; // write /0
		}

		if(bit_pos > 0) {
			++byte_size;
			bit_pos = 0; // give up rest bits in current byte
		}

		enlarge(len);
		memcpy(byte_ary + byte_size, str, len);
		byte_size += len;
	}

	//notice:some bits may not use in last byte
	int read_bits_available() {
		return (byte_size - read_byte_pos) * 8 - bit_pos;
	}

	bool read_bool() {
		return _read_flag();
	}

	int read_int(unsigned int bits) {
		if(bits == 0) {
			return 0;
		}

		if(_read_flag()) {
			return - (int)_read_u32(bits-1);
		}
		else {
			return (int)_read_u32(bits-1);
		}
	}

	unsigned int read_uint(unsigned int bits) {
		return _read_u32(bits);
	}

	float read_decimal(unsigned int bits) {
		return (int)_read_u32(bits) * 2 / (float)((1 << bits) - 1) - 1.0f;
	}

	float read_udecimal(unsigned int bits) {
		return _read_u32(bits) / (float)((1 << bits) - 1);
	}

	int read_str(char* str, int len) {
		if(len<=0) {
			return 0;
		}

		if(bit_pos > 0) {
			++read_byte_pos;
			bit_pos = 0; // give up rest bits in current byte
		}

		int readed_len = 0;
		char* src = byte_ary+read_byte_pos;
		for(; read_byte_pos<byte_size && *src && readed_len < len; ++readed_len,++src,++read_byte_pos,++str) {
			*str = *src;
		}
		if(readed_len == len) {
			--str;
		}
		*str = 0;

		for(; read_byte_pos<byte_size && *src; ++src, ++read_byte_pos) // ignore the rest bytes
			;

		if(read_byte_pos < byte_size) {
			++read_byte_pos;
		}

		return readed_len;
	}

	char* data() { return byte_ary; }

protected:
	bool _write_flag(bool b) {
		if(b) {
			byte_ary[byte_size] |= (0x1<<bit_pos);
		}
		else {
			byte_ary[byte_size] &= ~(0x1<<bit_pos);
		}

		++bit_pos;
		if(bit_pos >= 8) {
			++byte_size;
		}
		bit_pos &= 0x7;

		return b;
	}

	bool _read_flag() {
		bool ret = (bool)(byte_ary[read_byte_pos] & (0x1<<bit_pos));

		++bit_pos;
		if(bit_pos >= 8) {
			++read_byte_pos;
		}
		bit_pos &= 0x7;

		return ret;
	}

	void _write_u32(unsigned int i, unsigned int bits) {
		if(bits > 32) {
			bits = 32;
		}

		int rest_bits = bits;
		for(; rest_bits > 0;) {
			int empty_bits = 8 - bit_pos;
			int to_fill_bits = empty_bits > rest_bits ? rest_bits : empty_bits;

			byte_ary[byte_size] = (byte_ary[byte_size] & ((0x1<<bit_pos) - 1)) | (((i >> (bits-rest_bits)) & ((0x1<<to_fill_bits) - 1))<<bit_pos);

			bit_pos += to_fill_bits;
			if(bit_pos >= 8) {
				++byte_size;
			}
			bit_pos &= 0x7;

			rest_bits -= to_fill_bits;
		}
	}

	unsigned int _read_u32(unsigned int bits) {
		if(bits > 32) {
			bits = 32;
		}

		unsigned int ret = 0;
		int rest_bits = bits;
		for(; rest_bits > 0;) {
			int next_bits = 8 - bit_pos;
			int to_read_bits = next_bits > rest_bits ? rest_bits : next_bits;

			ret |= ((byte_ary[read_byte_pos] >> bit_pos) & ((0x1<<to_read_bits)-1)) << (bits-rest_bits);

			bit_pos += to_read_bits;
			if(bit_pos >= 8) {
				++read_byte_pos;
				bit_pos &= 0x7;
			}

			rest_bits -= to_read_bits;
		}

		return ret;
	}

	//write memory bytes bits to bytes ary
	void _write_bytes(const char* bytes, unsigned int len) {
		if(bit_pos > 0) {
			unsigned int i;
			int empty_bits = 8 - bit_pos;
			for(i=0; i< len; ++i) {
				byte_ary[byte_size] = (byte_ary[byte_size] & ((0x1<<bit_pos) - 1)) | ((bytes[i] & ((0x1<<empty_bits) - 1))<<bit_pos);
				++byte_size;
				byte_ary[byte_size] = (byte_ary[byte_size] & 0) | bytes[i] >> empty_bits;
			}
		}
		else {
			memcpy(byte_ary + byte_size, bytes, len);
			byte_size += len;
		}
	}

	//read memory byte bits from bytes ary
	void _read_bytes(char* bytes, unsigned int len) {
		if(bit_pos > 0) {
			unsigned int i;
			int next_bits = 8 - bit_pos;
			for(i=0; i< len; ++i) {
				bytes[i] = ((byte_ary[byte_size] >> bit_pos) & ((0x1<<next_bits)-1)) | (byte_ary[byte_size + 1] & ((0x1<<bit_pos) - 1))<<next_bits;
				++byte_size;
			}
		}
		else {
			memcpy(bytes, byte_ary + byte_size, len);
			read_byte_pos += len;
		}
	}

protected:
	char*	byte_ary;										//存放字节流的数组
	unsigned int byte_size;					//字节大小
	unsigned int byte_ary_capacity;	//字节数组容量
	unsigned int bit_pos;						//bit位置
	unsigned int read_byte_pos;			//读字节位置
	bool read_only;									//是否为只读buffer
};

#endif // #ifndef BIT_BUFFER_H_
