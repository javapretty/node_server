/*
 * Svc.h
 *
 *  Created on: Dec 16,2015
 *      Author: zhangyalei
 */

#ifndef SVC_H_
#define SVC_H_

#include "Block_List.h"
#include "Event_Handler.h"

class Svc;
class Svc_Handler {
public:
	typedef Block_List<Thread_Mutex> Data_Block_List;
	typedef std::vector<Block_Buffer *> Block_Vector;

	Svc_Handler(void);
	virtual ~Svc_Handler(void);

	void reset(void);
	void set_parent(Svc *parent) { parent_ = parent; }

	int push_recv_block(Block_Buffer *buffer);
	int push_send_block(Block_Buffer *buffer);

	virtual int handle_send(void) = 0;
	virtual int handle_pack(Block_Vector &block_vec) = 0;

protected:
	Svc *parent_;
	Data_Block_List recv_block_list_;
	Data_Block_List send_block_list_;

	size_t max_list_size_;
	size_t max_pack_size_;
};

class Endpoint;
class Svc: public Event_Handler {
public:
	typedef std::vector<Block_Buffer *> Block_Vector;
	
	Svc(void);
	virtual ~Svc(void);

	void reset(void);

	virtual Block_Buffer *pop_block(int cid);
	virtual int push_block(int cid, Block_Buffer *buffer);
	virtual int post_block(Block_Buffer* buffer);

	virtual int register_network_handler(void);
	virtual int unregister_network_handler(void);

	virtual int close_handler(int cid);

	int create_handler(int protocol_type);

	virtual int handle_input(void);
	virtual int handle_send(void);
	virtual int handle_close(void);
	int close_fd(void);

	inline int push_recv_block(Block_Buffer *buffer) {
		if (closed_) {
			return -1;
		} else {
			return handler_->push_recv_block(buffer);
		}
	}
	inline int push_send_block(Block_Buffer *buffer) {
		if (closed_) {
			return -1;
		} else {
			return handler_->push_send_block(buffer);
		}
	}

	inline void set_cid(int cid) { cid_ = cid; }
	inline int get_cid(void) { return cid_; }

	inline void set_closed(bool is_closed) { closed_ = is_closed; }
	inline bool closed(void) { return closed_; }

	inline void set_reg_network(bool reg_network) { reg_network_ = reg_network; }
	inline bool reg_network(void) { return reg_network_; }

	inline void set_peer_addr(void) { get_peer_addr(peer_ip_, peer_port_); }
	int get_peer_addr(std::string &ip, int &port);
	int get_local_addr(std::string &ip, int &port);

	inline std::string &get_peer_ip() { return peer_ip_; }
	inline int get_peer_port() { return peer_port_; }

	void set_endpoint(Endpoint *endpoint);
	int endpoint_type(void);

protected:
	Endpoint *endpoint_;

private:
	int cid_;
	bool closed_;
	bool reg_network_;
	std::string peer_ip_;
	int peer_port_;

	Svc_Handler *handler_;
};

inline void Svc::reset(void) {
	cid_ = 0;
	closed_ = false;
	reg_network_ = false;

	peer_ip_.clear();
	peer_port_ = 0;

	if (handler_) {
		handler_->reset();
		delete handler_;
		handler_ = 0;
	}
	endpoint_ = 0;
	Event_Handler::reset();
}

#endif /* SVC_H_ */
