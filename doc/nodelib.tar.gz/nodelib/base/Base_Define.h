/*
 * Base_Define.h
 *
 *  Created on: Sep 22, 2016
 *      Author: zhangyalei
 */

#ifndef BASE_DEFINE_H_
#define BASE_DEFINE_H_

#include <vector>
#include "Time_Value.h"

const static int SVC_MAX_LIST_SIZE = 1000;
const static int SVC_MAX_PACK_SIZE = 60 * 1024;

struct Data_Info {
	int file_size;
	int data_len;
	char* data;
} ;

struct Field_Info {
	std::string field_label;	//字段标签
	std::string field_type;		//字段类型
	std::string field_name;		//字段名称
	std::string key_type;			//主键类型
	std::string key_name;			//主键名称
};

struct Endpoint_Info {
	int endpoint_type;						//端点类型
	int endpoint_id;							//端点id
	std::string endpoint_name;	//端点名称
	std::string server_ip;				//服务器ip
	int server_port;							//服务器端口(如果是connect端点，该ip和port表示它要连接的服务器)
	int protocol_type;						//网络协议类型 0:Tcp 1:Udp 2:Websocket 3:Http
	int receive_timeout;					//服务器与客户端心跳时间 单位:s
};

class Block_Buffer;
struct Block_Group_Info {
	int free_list_size_;
	int used_list_size_;
	int sum_bytes_;

	void serialize(Block_Buffer &buf);
	void deserialize(Block_Buffer &buf);
	void reset(void);
};

struct Endpoint_Svc_Info {
	int svc_pool_free_list_size_;
	int svc_pool_used_list_size_;
	int svc_list_size_;
	std::vector<Block_Group_Info> block_group_info_;

	void serialize(Block_Buffer &buf);
	void deserialize(Block_Buffer &buf);
	void reset(void);
};

#endif /* BASE_DEFINE_H_ */
