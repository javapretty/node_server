/*
 * V8_Base.h
 *
 *  Created on: Oct 21, 2016
 *      Author: zhangyalei
 */

#ifndef V8_BASE_H_
#define V8_BASE_H_

#include <string>
#include "include/v8.h"

using namespace v8;

std::string to_string(const String::Utf8Value& value);
int run_script(Isolate* isolate, const char* file_path);
MaybeLocal<v8::String> read_file(Isolate* isolate, const char* file_path);
void report_exception(Isolate* isolate, TryCatch* handler, const char* file_path);

#endif /* V8_BASE_H_ */
