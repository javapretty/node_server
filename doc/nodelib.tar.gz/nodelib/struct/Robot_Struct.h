/*
 * Robot_Struct.h
 *
 *  Created on: Sep 27, 2016
 *      Author: zhangyalei
 */

#ifndef ROBOT_STRUCT_H_
#define ROBOT_STRUCT_H_

#include "Base_Struct.h"

class Robot_Struct: public Base_Struct {
public:
	Robot_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Robot_Struct();

	void write_buffer(Byte_Buffer &buffer);
	void read_buffer(Byte_Buffer &buffer);

private:
	void write_buffer_arg(const Field_Info &field_info, Byte_Buffer &buffer);
	void write_buffer_vector(const Field_Info &field_info, Byte_Buffer &buffer);
	void write_buffer_struct(const Field_Info &field_info, Byte_Buffer &buffer);

	void read_buffer_arg(const Field_Info &field_info, Byte_Buffer &buffer);
	void read_buffer_vector(const Field_Info &field_info, Byte_Buffer &buffer);
	void read_buffer_struct(const Field_Info &field_info, Byte_Buffer &buffer);
};

#endif /* ROBOT_STRUCT_H_ */
