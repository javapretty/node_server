/*
 * Robot_Struct.h
 *
 *  Created on: Sep 27, 2016
 *      Author: zhangyalei
 */

#ifndef ROBOT_STRUCT_H_
#define ROBOT_STRUCT_H_

#include "Base_Struct.h"

class Robot_Struct: public Base_Struct {
public:
	Robot_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Robot_Struct();

	//读写byte_buffer
	void write_byte_buffer(Byte_Buffer &buffer);
	void read_byte_buffer(Byte_Buffer &buffer);

	//读写bit_buffer
	void write_bit_buffer(Bit_Buffer &buffer);
	void read_bit_buffer(Bit_Buffer &buffer);

private:
	//读写byte_buffer
	void write_byte_buffer_arg(const Field_Info &field_info, Byte_Buffer &buffer);
	void write_byte_buffer_vector(const Field_Info &field_info, Byte_Buffer &buffer);
	void write_byte_buffer_struct(const Field_Info &field_info, Byte_Buffer &buffer);

	void read_byte_buffer_arg(const Field_Info &field_info, Byte_Buffer &buffer);
	void read_byte_buffer_vector(const Field_Info &field_info, Byte_Buffer &buffer);
	void read_byte_buffer_struct(const Field_Info &field_info, Byte_Buffer &buffer);

	//读写bit_buffer
	void write_bit_buffer_arg(const Field_Info &field_info, Bit_Buffer &buffer);
	void write_bit_buffer_vector(const Field_Info &field_info, Bit_Buffer &buffer);
	void write_bit_buffer_struct(const Field_Info &field_info, Bit_Buffer &buffer);

	void read_bit_buffer_arg(const Field_Info &field_info, Bit_Buffer &buffer);
	void read_bit_buffer_vector(const Field_Info &field_info, Bit_Buffer &buffer);
	void read_bit_buffer_struct(const Field_Info &field_info, Bit_Buffer &buffer);
};

#endif /* ROBOT_STRUCT_H_ */
