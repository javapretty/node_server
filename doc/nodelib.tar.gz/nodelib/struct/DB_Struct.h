/*
 * DB_Struct.h
 *
 *  Created on: Oct 21, 2016
 *      Author: zhangyalei
 */

#ifndef DB_STRUCT_H_
#define DB_STRUCT_H_

#include "Base_Struct.h"

class DB_Struct: public Base_Struct {
public:
	DB_Struct(Xml &xml, TiXmlNode *node);
	virtual ~DB_Struct();

	inline const bool db_init() { return db_init_; }
	inline void set_db_init() { db_init_ = true; }

private:
	bool db_init_;
};

#endif /* DB_STRUCT_H_ */
