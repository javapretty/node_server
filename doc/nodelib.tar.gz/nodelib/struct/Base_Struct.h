/*
 * Base_Struct.h
 *
 *  Created on: May 30, 2016
 *      Author: zhangyalei
 */
 
#ifndef BASE_STRUCT_H_
#define BASE_STRUCT_H_

#include "Block_Buffer.h"
#include "Base_Define.h"
#include "Xml.h"
#include "include/v8.h"

using namespace v8;
class Base_Struct {
public:
	Base_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Base_Struct();

	inline const std::string &struct_name() { return struct_name_; }
	inline const std::string &table_name() { return table_name_; }
	inline const std::string &db_name() { return db_name_; }
	inline const std::string &index_name() { return index_name_; }
	inline const std::vector<Field_Info>& field_vec() { return field_vec_; }
	inline bool is_struct(const std::string &type);

	v8::Local<v8::Object> build_object(Isolate* isolate, Block_Buffer &buffer);
	void build_buffer(Isolate* isolate, v8::Local<v8::Object> object, Block_Buffer &buffer);

	v8::Local<v8::Value> build_object_arg(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer);
	v8::Local<v8::Array> build_object_vector(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer);
	v8::Local<v8::Map> build_object_map(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer);
	v8::Local<v8::Object> build_object_struct(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer);

	void build_buffer_arg(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer, v8::Local<v8::Value> value);
	void build_buffer_vector(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer, v8::Local<v8::Value> value);
	void build_buffer_map(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer, v8::Local<v8::Value> value);
	void build_buffer_struct(Isolate* isolate, const Field_Info &field_info, Block_Buffer &buffer, v8::Local<v8::Value> value);

private:
	std::string struct_name_;
	std::string db_name_;
	std::string table_name_;
	std::string index_name_;
	std::vector<Field_Info> field_vec_;
};

/////////////////////////////////////////////////////////////////////////////////////////////////
inline bool Base_Struct::is_struct(const std::string &field_type){
	if(field_type == "int8" || field_type == "int16" || field_type == "int32" || field_type == "int64" ||
		 field_type == "uint8" || field_type == "uint16" || field_type == "uint32" || field_type == "uint64" ||
		 field_type == "double" || field_type == "bool" || field_type == "string") return false;
	return true;
}

#endif /* BASE_STRUCT_H_ */
