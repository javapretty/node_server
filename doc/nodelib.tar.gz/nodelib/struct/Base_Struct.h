/*
 * Base_Struct.h
 *
 *  Created on: May 30, 2016
 *      Author: zhangyalei
 */
 
#ifndef BASE_STRUCT_H_
#define BASE_STRUCT_H_

#include "include/v8.h"
#include "json/json.h"
#include "Base_Define.h"
#include "Byte_Buffer.h"
#include "Bit_Buffer.h"
#include "Xml.h"

using namespace v8;
class Base_Struct {
public:
	Base_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Base_Struct();

	int init_field(Xml &xml, TiXmlNode *node, Field_Info &field_info);

	inline const std::string &struct_name() { return struct_name_; }
	inline const std::string &table_name() { return table_name_; }
	inline const std::string &db_name() { return db_name_; }
	inline const std::string &index_name() { return index_name_; }
	inline const int msg_id() { return msg_id_; }
	inline const std::string &msg_name() { return msg_name_; }
	inline const std::vector<Field_Info>& field_vec() { return field_vec_; }
	inline bool is_struct(const std::string &type);

	//将Byte_Buffer转成v8::object
	v8::Local<v8::Object> build_byte_object(Isolate* isolate, Byte_Buffer &buffer);
	//将v8::object转换Byte_Buffer
	void build_byte_buffer(Isolate* isolate, v8::Local<v8::Object> object, Byte_Buffer &buffer);
	//Bit_Buffer转成v8::object
	v8::Local<v8::Object> build_bit_object(Isolate* isolate, Bit_Buffer &buffer);
	//将v8::object转换Bit_Buffer
	void build_bit_buffer(Isolate* isolate, v8::Local<v8::Object> object, Bit_Buffer &buffer);

	//将Json::Value转成v8::object
	v8::Local<v8::Value> build_object_arg(Isolate* isolate, const Field_Info &field_info, const Json::Value &value);
	v8::Local<v8::Array> build_object_vector(Isolate* isolate, const Field_Info &field_info, const Json::Value &value);
	v8::Local<v8::Map> build_object_map(Isolate* isolate, const Field_Info &field_info, const Json::Value &value);
	v8::Local<v8::Object> build_object_struct(Isolate* isolate, const Field_Info &field_info, const Json::Value &value);

	//将Byte_Buffer转成v8::object
	v8::Local<v8::Value> build_byte_object_arg(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer);
	v8::Local<v8::Array> build_byte_object_vector(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer);
	v8::Local<v8::Map> build_byte_object_map(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer);
	v8::Local<v8::Object> build_byte_object_struct(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer);

	//将v8::object转换Byte_Buffer
	void build_byte_buffer_arg(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer, v8::Local<v8::Value> value);
	void build_byte_buffer_vector(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer, v8::Local<v8::Value> value);
	void build_byte_buffer_map(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer, v8::Local<v8::Value> value);
	void build_byte_buffer_struct(Isolate* isolate, const Field_Info &field_info, Byte_Buffer &buffer, v8::Local<v8::Value> value);

	//Bit_Buffer转成v8::object
	v8::Local<v8::Value> build_bit_object_arg(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer);
	v8::Local<v8::Array> build_bit_object_vector(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer);
	v8::Local<v8::Map> build_bit_object_map(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer);
	v8::Local<v8::Object> build_bit_object_struct(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer);

	//将v8::object转换Bit_Buffer
	void build_bit_buffer_arg(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer, v8::Local<v8::Value> value);
	void build_bit_buffer_vector(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer, v8::Local<v8::Value> value);
	void build_bit_buffer_map(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer, v8::Local<v8::Value> value);
	void build_bit_buffer_struct(Isolate* isolate, const Field_Info &field_info, Bit_Buffer &buffer, v8::Local<v8::Value> value);

private:
	std::string struct_name_;
	std::string db_name_;
	std::string table_name_;
	std::string index_name_;
	int msg_id_;
	std::string msg_name_;
	std::vector<Field_Info> field_vec_;
};

/////////////////////////////////////////////////////////////////////////////////////////////////
inline bool Base_Struct::is_struct(const std::string &field_type){
	if(field_type == "int8" || field_type == "int16" || field_type == "int32" || field_type == "int64" ||
		 field_type == "uint8" || field_type == "uint16" || field_type == "uint32" || field_type == "uint64" ||
		 field_type == "double" || field_type == "bool" || field_type == "string" ||
		 field_type == "int" || field_type == "uint" || field_type == "decimal" || field_type == "udeciaml") return false;
	return true;
}

#endif /* BASE_STRUCT_H_ */
