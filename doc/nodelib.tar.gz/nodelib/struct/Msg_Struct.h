/*
 * Msg_Struct.h
 *
 *  Created on: Aug 2, 2016
 *      Author: zhangyalei
 */

#ifndef MSG_STRUCT_H_
#define MSG_STRUCT_H_

#include "json/json.h"
#include "Base_Struct.h"

class Msg_Struct: public Base_Struct {
public:
	Msg_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Msg_Struct();

	v8::Local<v8::Object> build_http_msg_object(Isolate* isolate, int cid, const Json::Value &value);
	void build_http_msg_buffer(Isolate* isolate, v8::Local<v8::Object> object, std::string &str);

	v8::Local<v8::Object> build_msg_object(Isolate* isolate, int cid, int msg_id, int msg_type, uint32_t sid, Block_Buffer &buffer);
	void build_msg_buffer(Isolate* isolate, v8::Local<v8::Object> object, Block_Buffer &buffer);

};
#endif /* MSG_STRUCT_H_ */
