/*
 * Msg_Struct.h
 *
 *  Created on: Aug 2, 2016
 *      Author: zhangyalei
 */

#ifndef MSG_STRUCT_H_
#define MSG_STRUCT_H_

#include "Base_Struct.h"

class Msg_Struct: public Base_Struct {
public:
	Msg_Struct(Xml &xml, TiXmlNode *node);
	virtual ~Msg_Struct();

	v8::Local<v8::Object> build_http_msg_object(Isolate* isolate, int cid, int msg_id, int msg_type, const Json::Value &value);
	v8::Local<v8::Object> build_msg_object(Isolate* isolate, int cid, int msg_id, int msg_type, uint32_t sid, Byte_Buffer &buffer);
};
#endif /* MSG_STRUCT_H_ */
