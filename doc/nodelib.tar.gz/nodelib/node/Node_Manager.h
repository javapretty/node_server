/*
 * Node_Manager.h
  *
 *  Created on: Sep 20, 2016
 *      Author: zhangyalei
 */

#ifndef NODE_MANAGER_H_
#define NODE_MANAGER_H_

#include "Node_Endpoint.h"

class Node_Manager: public Thread {
public:
	typedef Object_Pool<Server, Mutex_Lock> Server_Pool;
	typedef Object_Pool<Connector, Mutex_Lock> Connector_Pool;

	typedef List<Drop_Info, Mutex_Lock> Drop_List;
	typedef List<int, Mutex_Lock> Int_List;
	typedef std::unordered_map<int, Node_Info> Node_Map;		//node_type--node_info
	typedef std::unordered_map<int, Endpoint *> Endpoint_Map;	//endpoint_id--endpoint
public:
	static Node_Manager *instance(void);

	//初始化
	int init(int node_type, int node_id, int endpoint_gid, const std::string &node_name);
	int init_node_info(void);
	//主动关闭
	int self_close(void);
	//通知daemon创建进程
	int fork_process(int node_type, int node_id, int endpoint_gid, std::string &node_name);

	virtual void run_handler(void);
	virtual int process_list(void);

	inline Node_Info &node_info(void) { return node_info_; }
	inline void push_tick(int tick) {
		notify_lock_.lock();
		tick_list_.push_back(tick);
		notify_lock_.signal();
		notify_lock_.unlock();
	}
	//添加掉线cid
	inline void push_drop(int eid, int cid) { drop_list_.push_back(Drop_Info(eid, cid)); }
	//回收消息buffer
	inline int push_buffer(int eid, int cid, Byte_Buffer *buffer);
	//消息过滤器，被过滤的消息，不会抛给脚本层，直接由C++处理
	inline bool msg_filter(int msg_type, int msg_id);
	//发送消息
	int send_msg(const Msg_Head &msg_head, char const *data, size_t len);
	//释放进程pool缓存，后台调用
	int free_pool(void);

	//定时器处理
	int tick(void);
	inline const Time_Value &tick_time(void) { return tick_time_; }
	int drop_list_tick(Time_Value &now);		//关闭连接定时器
	int node_info_tick(Time_Value &now);		//收集服务器信息定时器

	//服务器信息收集
	virtual void get_node_info(void);
	virtual void print_node_info(void);

private:
	Node_Manager(void);
	virtual ~Node_Manager(void);
	Node_Manager(const Node_Manager &);
	const Node_Manager &operator=(const Node_Manager &);

private:
	static Node_Manager *instance_;

	Drop_List drop_list_; 		//逻辑层发起的掉线cid列表
	Int_List tick_list_;		//定时器列表

	Time_Value tick_time_;		//节点tick时间
	Time_Value node_info_tick_;	//节点信息tick

	Server_Pool server_pool_;
	Connector_Pool connector_pool_;

	int msg_filter_count_;		//消息过滤器数量
	Node_Info node_info_;		//本进程节点信息
	Node_Map node_map_;			//节点信息
	Endpoint_Map endpoint_map_;	//通信端信息
};

#define NODE_MANAGER Node_Manager::instance()

int Node_Manager::push_buffer(int eid, int cid, Byte_Buffer *buffer) {
	Endpoint_Map::iterator iter = endpoint_map_.find(eid);
	if (iter != endpoint_map_.end()) {
		iter->second->push_buffer(cid, buffer);
	}
	return 0;
}

bool Node_Manager::msg_filter(int msg_type, int msg_id) {
	for (int i = 0; i < msg_filter_count_; ++i) {
		if (msg_type == node_info_.filter_list[i].msg_type && msg_id >= node_info_.filter_list[i].min_msg_id
				&& msg_id <= node_info_.filter_list[i].max_msg_id) {
			return true;
		}
	}
	return false;
}

#endif /* NODE_MANAGER_H_ */
