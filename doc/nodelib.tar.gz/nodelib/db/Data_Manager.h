/*
 * Data_Manager.h
 *
 *  Created on: Oct 27, 2016
 *      Author: zhangyalei
 */

#ifndef DATA_MANAGER_H_
#define DATA_MANAGER_H_

#include <unordered_map>
#include "Object_Pool.h"
#include "DB_Operator.h"

class Data_Manager {
public:
	typedef std::unordered_map<int, DB_Operator *> DB_Operator_Map;					//db_id--DB_Operator
	typedef std::unordered_map<int64_t, Bit_Buffer *> Record_Buffer_Map; 	//index--buffer
	typedef std::unordered_map<std::string, Record_Buffer_Map *> Table_Buffer_Map;//table_name--record
	typedef std::unordered_map<int, Table_Buffer_Map *> DB_Buffer_Map; 			//db_id--table_buffer
	typedef std::unordered_map<int64_t, Bit_Buffer *> Runtime_Buffer_Map;		//index--buffer
	typedef std::unordered_map<std::string, Runtime_Buffer_Map *> Runtime_Data_Map; //key_name--buffer_map
	typedef Object_Pool<Bit_Buffer, Mutex_Lock> Buffer_Pool;

	typedef std::unordered_map<std::string, int> TABLE_MAP;
public:
	static Data_Manager *instance(void);

	//数据库初始化接口
	int init_db_operator();
	bool connect_to_db(int db_id, std::string &ip, int port, std::string &user, std::string &password, std::string &pool_name);
	int64_t generate_table_index(int db_id, DB_Struct *db_struct, std::string &type);
	int64_t select_table_index(int db_id, DB_Struct *db_struct, std::string &query_name, std::string &query_value);

	//数据库数据操作接口
	int load_db_data(int db_id, DB_Struct *db_struct, int64_t index, std::vector<Bit_Buffer *> &buffer_vec);
	int save_db_data(int save_flag, int db_id, DB_Struct *db_struct, Bit_Buffer *buffer);
	int delete_db_data(int db_id, DB_Struct *db_struct, Bit_Buffer *buffer);

	//运行时数据操作接口
	void set_runtime_data(int64_t index, DB_Struct *db_struct, Bit_Buffer *buffer);
	Bit_Buffer *get_runtime_data(int64_t index, DB_Struct *db_struct);
	void delete_runtime_data(int64_t index, DB_Struct *db_struct);

	inline Bit_Buffer *pop_buffer() { return buffer_pool_.pop(); };
	inline void push_buffer(Bit_Buffer *buffer) {
		buffer->reset();
		buffer_pool_.push(buffer);
	};

private:
	Data_Manager(void);
	virtual ~Data_Manager(void);
	Data_Manager(const Data_Manager &);
	const Data_Manager &operator=(const Data_Manager &);

	DB_Operator *get_db_operator(int db_id) {
		DB_Operator_Map::iterator iter = db_operator_map_.find(db_id / 1000);
		if(iter != db_operator_map_.end()) {
			return iter->second;
		} else {
			LOG_ERROR("db_id %d error", db_id);
			return nullptr;
		}
	}
	Record_Buffer_Map *get_record_map(int db_id, std::string table_name);
	Runtime_Buffer_Map *get_runtime_buffer_map(std::string key_name);
private:
	static Data_Manager *instance_;
	DB_Operator_Map db_operator_map_;
	DB_Buffer_Map db_buffer_map_;
	Runtime_Data_Map runtime_data_map_;
	Buffer_Pool buffer_pool_;
};

#define DATA_MANAGER 	Data_Manager::instance()

#endif /* DATA_MANAGER_H_ */
