/*
 * Data_Manager.h
 *
 *  Created on: Oct 27, 2016
 *      Author: zhangyalei
 */

#ifndef DATA_MANAGER_H_
#define DATA_MANAGER_H_

#include <unordered_map>
#include "Object_Pool.h"
#include "DB_Operator.h"

class Data_Manager {
public:
	typedef std::unordered_map<int, DB_Operator *> DB_Operator_Map;					//db_id--DB_Operator
	typedef std::unordered_map<int64_t, Bit_Buffer *> Record_Buffer_Map; 	//index--buffer
	typedef std::unordered_map<std::string, Record_Buffer_Map *> Table_Buffer_Map;//table_name--record
	typedef std::unordered_map<int, Table_Buffer_Map *> DB_Buffer_Map; 			//db_id--table_buffer
	typedef std::unordered_map<int64_t, Bit_Buffer *> Runtime_Buffer_Map;		//index--buffer
	typedef std::unordered_map<std::string, Runtime_Buffer_Map *> Runtime_Data_Map; //key_name--buffer_map
	typedef Object_Pool<Bit_Buffer, Mutex_Lock> Buffer_Pool;
public:
	static Data_Manager *instance(void);

	//数据库初始化接口
	int init_db_operator();
	bool connect_to_db(int db_id, std::string &ip, int port, std::string &user, std::string &password, std::string &pool_name);
	int64_t generate_id(int db_id, std::string &table_name, std::string &type);
	int64_t get_table_index(int db_id, std::string &table_name, std::string &index_name, std::string &query_name, std::string &query_value);

	//操作db数据接口
	void load_db_data(int db_id, const std::string &struct_name, int64_t key_index, Bit_Buffer &buffer);
	void save_db_data(int save_type, bool vector_data, int db_id, const std::string &struct_name, Bit_Buffer &buffer);
	void delete_db_data(int db_id, const std::string &struct_name, Bit_Buffer &buffer);

	//操作运行时数据接口
	void load_runtime_data(const std::string &struct_name, int64_t key_index, Bit_Buffer &buffer);
	void save_runtime_data(const std::string &struct_name, int64_t key_index, Bit_Buffer &buffer);
	void delete_runtime_data(const std::string &struct_name, int64_t key_index);

	void print_db_data(void);

	inline Bit_Buffer *pop_buffer() { return buffer_pool_.pop(); };
	inline void push_buffer(Bit_Buffer *buffer) {
		buffer->reset();
		buffer_pool_.push(buffer);
	};

private:
	Data_Manager(void);
	virtual ~Data_Manager(void);
	Data_Manager(const Data_Manager &);
	const Data_Manager &operator=(const Data_Manager &);

	DB_Operator *get_db_operator(int db_id) {
		DB_Operator_Map::iterator iter = db_operator_map_.find(db_id / 1000);
		if(iter != db_operator_map_.end()) {
			return iter->second;
		} else {
			LOG_ERROR("db_id %d error", db_id);
			return nullptr;
		}
	}

	//操作db缓存和db数据库接口
	int load_db_data(int db_id, DB_Struct *db_struct, int64_t key_index, std::vector<Bit_Buffer *> &buffer_vec);
	int save_db_data(int save_type, int db_id, DB_Struct *db_struct, Bit_Buffer &buffer);
	int delete_db_data(int db_id, DB_Struct *db_struct, Bit_Buffer &buffer);

	Record_Buffer_Map *get_record_map(int db_id, std::string table_name);
	Runtime_Buffer_Map *get_runtime_buffer_map(std::string key_name);
private:
	static Data_Manager *instance_;
	DB_Operator_Map db_operator_map_;
	DB_Buffer_Map db_buffer_map_;
	Runtime_Data_Map runtime_data_map_;
	Buffer_Pool buffer_pool_;
};

#define DATA_MANAGER 	Data_Manager::instance()

#endif /* DATA_MANAGER_H_ */
